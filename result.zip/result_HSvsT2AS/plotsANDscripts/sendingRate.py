#!/usr/bin/env python

import sys
import math

finalPath = ""
finalPath += sys.argv[3]
finalPath += sys.argv[1]
Log_uinjectSndr_file = open(finalPath)
Log_uinjectSndr_pkts = Log_uinjectSndr_file.readlines()
Log_uinjectSndr_file.close()

# Get Number of motes that are emulated
Num_Mote = 0
for line in Log_uinjectSndr_pkts:
	y = line.split()
	if int(y[0]) > Num_Mote:
		Num_Mote = int(y[0])

#rows: mote id
# col0: moteID, col1: NumOfPackets, col2: whole Time alive, col3: meanRate
rateLog = [[0 for i in range(4)] for j in range(Num_Mote)]
		
for p in range(Num_Mote-1):
	i = 0
	firstTime = 0
	secondTime = 0
	difference = 0
	pktCounter = 1
	for line in Log_uinjectSndr_pkts:
		x = line.split()
		if int(x[0]) == p+2:
			if i == 0:
				firstTime = int(x[1])*3600000 + int(x[2])*60000 + int(x[3])*1000 + int(x[4])
				i+=1
				continue
			y = line.split()
			secondTime = int(y[1])*3600000 + int(y[2])*60000 + int(y[3])*1000 + int(y[4])
			difference = secondTime - firstTime
			pktCounter+=1
	rateLog[p][0]=p+2
	rateLog[p][1]=pktCounter
	rateLog[p][2]=difference
	rateLog[p][3]=float(difference)/pktCounter

finalPath = ""
finalPath += sys.argv[3]
finalPath += "sendingRate"
finalPath += sys.argv[2]
finalPath += sys.argv[4]
finalPath += ".txt"
outfile = open(finalPath, 'w')

for i in range(Num_Mote-1):
	for j in range(4):
		outfile.write(str(rateLog[i][j]));
		outfile.write(' ');
	outfile.write('\n');

outfile.close()

