#!/usr/bin/env python

import math

Num_Topo = 7
HS = [[0 for i in range(5)] for j in range(Num_Topo)]	
T2AS = [[0 for i in range(5)] for j in range(Num_Topo)]

numOfMotes = 4 # topology size = numOfMotes + i // to get right address of files
for i in range(Num_Topo):
	fileName = "_Get_moteID_queueLength.txt"
	pathHS = "../hs/%dMotes/results/%s" % (i+numOfMotes, fileName)
	pathT2AS = "../t2as/%dMotes/results/%s" % (i+numOfMotes, fileName)
	with open(pathHS) as infile:
		for line in infile:
			y = line.split()
			HS[i][0] = int(y[0])
			HS[i][1] += float(y[3])
	infile.close()
	with open(pathT2AS) as infile:
		for line in infile:
			y = line.split()
			T2AS[i][0] = int(y[0])
			T2AS[i][1] += float(y[3])
	infile.close()

	# average duty cycle
	fileName = "_Get_moteID_dutyCycle.txt"
	pathHS = "../hs/%dMotes/results/%s" % (i+numOfMotes, fileName)
	pathT2AS = "../t2as/%dMotes/results/%s" % (i+numOfMotes, fileName)
	with open(pathHS) as infile:
		for line in infile:
			y = line.split()
			if int(y[0]) != 1:
				HS[i][2] += float(y[3])
	infile.close()
	
	with open(pathT2AS) as infile:
		for line in infile:
			y = line.split()
			if int(y[0]) != 1:
				T2AS[i][2] += float(y[3])
	infile.close()

	# average delay & pdr
	fileName = "_Get_DELAY_PDR.txt"
	pathHS = "../hs/%dMotes/results/%s" % (i+numOfMotes, fileName)
	pathT2AS = "../t2as/%dMotes/results/%s" % (i+numOfMotes, fileName)
	with open(pathHS) as infile:
		for line in infile:
			y = line.split()
			HS[i][3] += float(y[5])
			HS[i][4] += float(y[3])
	infile.close()
	with open(pathT2AS) as infile:
		for line in infile:
			y = line.split()
			T2AS[i][3] += float(y[5])
			T2AS[i][4] += float(y[3])
	infile.close()
	
	numOfMotes+=1


# write results to file
avg_file = open('avgAll.txt','w')
for i in range(Num_Topo):
	avg_file.write(str(HS[i][0]+1))
	avg_file.write(' ')
	for j in range(1,5):
		avg_file.write(str(T2AS[i][j]/T2AS[i][0]))
		avg_file.write(' ')
		avg_file.write(str(HS[i][j]/HS[i][0]))
		avg_file.write(' ')
	avg_file.write('\n')
avg_file.close()

'''
# description of HS & T2AS arrays
Both are two dimentions 7*5

each row is specified to one topology size: 4 6 8 10 12 14 16
coll 0: topology size
coll 1: sum of queue length for each topo
coll 2: sum of duty cycle for each topo
coll 3: sum of delay for each topo
coll 4: sum of pdr for each topo

# output
each row is specified to one topology size: 4 6 8 10 12 14 16
coll 0: topology size
coll 1: average of queue length for each topo of T2AS
coll 2: average of queue length for each topo of HS
coll 3: average of duty cycle for each topo T2AS
coll 4: average of duty cycle for each topo HS
coll 5: average of delay for each topo T2AS
coll 6: average of delay for each topo HS
coll 7: average of pdr for each topo T2AS
coll 8: average of pdr for each topo HS


'''
