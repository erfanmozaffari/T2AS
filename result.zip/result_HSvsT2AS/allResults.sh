#!/bin/bash

./retreiveMetricsHSandT2AS.sh
./HSandT2ASplots.sh
./comparePlots.sh
./sendingRateHSandT2AS.sh

cd ./queue/fluctuation
./fluctQueue.sh

cd ./../diffQueueSize
./QueueSize.sh