#!/usr/bin/env python

import math

# Get receive time of a packet
with open('_Log_Iphc_Rcv.txt') as Rcv_file:
	rcv_timefile = open('_Get_duprcv_time.txt','w')
	for line in Rcv_file:
		y = line.split()
		if len(y) == 5: # First Line of a logged Packet
			rcv_timefile.write(y[0])  # Mote ID
			rcv_timefile.write(' ')
			rcv_timefile.write(y[1])  # Rcv hour
			rcv_timefile.write(' ')
			rcv_timefile.write(y[2])  # Rcv minutes
			rcv_timefile.write(' ')
			rcv_timefile.write(y[3])  # Rcv sec
			rcv_timefile.write(' ')
			rcv_timefile.write(y[4])  # Rcv ms
			rcv_timefile.write(' ')
			SenderID = y[0]
		elif len(y) > 5:  # Second Line of a logged Packet
			for index in range(len(y)):
				if (int(y[index]) == 20) and (int(y[index+1]) == 200) and (int(y[index-3]) == int(SenderID)):
					pktID=int(y[index-2])*255+int(y[index-1])
					rcv_timefile.write(str(pktID))  # Packet ID
					rcv_timefile.write(' ')
					rcv_timefile.write(y[index-3])  # Sender's ID
					break
			rcv_timefile.write('\n')
	rcv_timefile.close()
Rcv_file.close()

# delete duplicated received pkts
infile = open('_Get_duprcv_time.txt', 'r')
firstHandler = infile.readlines()
infile.close()
newopen = open('_Get_rcv_time.txt', 'w')

i = 0
listLength = len(firstHandler)
while (i < listLength):
    newopen.write(firstHandler[i])
    y = firstHandler[i].split()
    j = i + 1
    while(j < listLength):
        x = firstHandler[j].split()
        if ((y[5] == x[5]) and (y[6] == x[6])):
            del firstHandler[j]
            listLength -= 1
            j-=1 #when you remove a line afterward lines index decreases one unit
        j += 1
    i += 1
newopen.close()

# Get open queue sent time of a packet
with open('_Log_OpenQueue_Snt.txt') as Snt_file:
	snd_timefile = open('_Get_dupsnt_time.txt','w')
	for line in Snt_file:
		y = line.split()
		if len(y) == 6  or len(y)==7: # First Line of a logged Packet
			snd_timefile.write(y[0])  # Mote ID
			snd_timefile.write(' ')
			snd_timefile.write(y[1])  # Snt hour
			snd_timefile.write(' ')
			snd_timefile.write(y[2])  # Snt minutes
			snd_timefile.write(' ')
			snd_timefile.write(y[3])  # Snt sec
			snd_timefile.write(' ')
			snd_timefile.write(y[4])  # Snt ms
			snd_timefile.write(' ')
			SenderID = y[0]
		elif len(y) > 7:  # Second Line of a logged Packet
			for index in range(len(y)):
				if (int(y[index]) == 20) and (int(y[index+1]) == 200) and (int(y[index-3]) == int(SenderID)):
					pktID=int(y[index-2])*255+int(y[index-1])
					snd_timefile.write(str(pktID))  # Packet ID
					snd_timefile.write(' ')
					snd_timefile.write(y[index-3])  # Sender's ID
					break
			snd_timefile.write('\n')
	snd_timefile.close()
Snt_file.close()

# delete duplicated sent pkts from openQueue
infile = open('_Get_dupsnt_time.txt', 'r')
firstHandler = infile.readlines()
infile.close()
newopen = open('_Get_snt_time.txt', 'w')

i = 0
listLength = len(firstHandler)
while (i < listLength):
    newopen.write(firstHandler[i])
    y = firstHandler[i].split()
    j = i + 1
    while(j < listLength):
        x = firstHandler[j].split()
        if ((y[5] == x[5]) and (y[6] == x[6])):
            del firstHandler[j]
            listLength -= 1
            j-=1 #when you remove a line afterward lines index decreases one unit
        j += 1
    i += 1
newopen.close()

# Get uinject sent time of a packet
with open('_Log_UINJECTApp_Sndr.txt') as uinjectSnt_file:
	uinjectsnd_timefile = open('_Get_UINJECTsndr_time.txt','w')
	for line in uinjectSnt_file:
		y = line.split()
		if len(y) == 6  or len(y)==7: # First Line of a logged Packet
			uinjectsnd_timefile.write(y[0])  # Mote ID
			uinjectsnd_timefile.write(' ')
			uinjectsnd_timefile.write(y[1])  # Snt hour
			uinjectsnd_timefile.write(' ')
			uinjectsnd_timefile.write(y[2])  # Snt minutes
			uinjectsnd_timefile.write(' ')
			uinjectsnd_timefile.write(y[3])  # Snt sec
			uinjectsnd_timefile.write(' ')
			uinjectsnd_timefile.write(y[4])  # Snt ms
			uinjectsnd_timefile.write(' ')
			SenderID = y[0]
		elif len(y) > 7:  # Second Line of a logged Packet
			for index in range(len(y)):
				if (int(y[index]) == 20) and (int(y[index+1]) == 200) and (int(y[index-3]) == int(SenderID)):
					pktID=int(y[index-2])*255+int(y[index-1])
					uinjectsnd_timefile.write(str(pktID))  # Packet ID
					uinjectsnd_timefile.write(' ')
					uinjectsnd_timefile.write(y[index-3])  # Sender's ID
					break
			uinjectsnd_timefile.write('\n')
	uinjectsnd_timefile.close()
uinjectSnt_file.close()


# Put togather sent an received time of a packet into a file
Log_Rcv_file = open('_Get_rcv_time.txt')
Rcv_pkts = Log_Rcv_file.readlines()
Log_Rcv_file.close()

Log_Snt_file = open('_Get_snt_time.txt')
Snt_pkts = Log_Snt_file.readlines()
Log_Snt_file.close()

Log_Snt_Rcv_file = open('_Get_snd_rcv_time.txt','w')

for rcv_line in Rcv_pkts:
	rcv_y = rcv_line.split()
	if len(rcv_y) > 5 :
		for snt_line in Snt_pkts:
			snt_y = snt_line.split()
			if len(snt_y) > 5 :
				if (int(rcv_y[0])==int(snt_y[0])) and (int(rcv_y[5])==int(snt_y[5])) and (int(rcv_y[6])==int(snt_y[6])):
					Log_Snt_Rcv_file.write(rcv_y[0])  # Sender ID
					Log_Snt_Rcv_file.write(' ')
					Log_Snt_Rcv_file.write(rcv_y[1])  # Rcv Hour
					Log_Snt_Rcv_file.write(' ')
					Log_Snt_Rcv_file.write(rcv_y[2])  # Rcv Minutes
					Log_Snt_Rcv_file.write(' ')
					Log_Snt_Rcv_file.write(rcv_y[3])  # Rcv Second
					Log_Snt_Rcv_file.write(' ')
					Log_Snt_Rcv_file.write(rcv_y[4])  # Rcv Milisecond
					Log_Snt_Rcv_file.write(' ')
					Log_Snt_Rcv_file.write(snt_y[1])  # Snt Hour
					Log_Snt_Rcv_file.write(' ')
					Log_Snt_Rcv_file.write(snt_y[2])  # Snt Minutes
					Log_Snt_Rcv_file.write(' ')
					Log_Snt_Rcv_file.write(snt_y[3])  # Snt Second
					Log_Snt_Rcv_file.write(' ')
					Log_Snt_Rcv_file.write(snt_y[4])  # Snt Milisecond
					Log_Snt_Rcv_file.write(' ')
					Log_Snt_Rcv_file.write(snt_y[5])  # Packet ID
					Log_Snt_Rcv_file.write('\n')
					break
			
Log_Snt_Rcv_file.close()


Log_uinjectSndr_file = open('_Get_UINJECTsndr_time.txt')
Log_uinjectSndr_pkts = Log_uinjectSndr_file.readlines()
Log_uinjectSndr_file.close()

# Get Number of motes that are emulated
Num_Mote = 0
for line in Log_uinjectSndr_pkts:
	y = line.split()
	if int(y[0]) > Num_Mote:
		Num_Mote = int(y[0])

# Get Duty Cycle
# find number of rows for each mote. then calculate the avg of second half of logs
# last logs are more stable.
dutyLogCounting = [-1 for j in range(Num_Mote)]

# get sum of duty cycles and number of logs
sumDutyCycle = [[0 for i in range(2)] for j in range(Num_Mote)]	

with open('_Log_DutyCycle.txt') as dutyCycle_filehandler:
	for line in dutyCycle_filehandler:
		y = line.split()
		#check_full_synch = 1
		#for i in range(Num_Mote):
		#	if dutyLogCounting[i] == -1:
		#		dutyLogCounting[int(y[0])-1] = 0
		#		check_full_synch = 0
		#if check_full_synch == 1:
		sumDutyCycle[int(y[0])-1][0] += 1
		sumDutyCycle[int(y[0])-1][1] += float(y[5])

	moteIdBased_dutyCycle_file = open('_Get_moteID_dutyCycle.txt','w')
	for i in range(Num_Mote):
		moteIdBased_dutyCycle_file.write(str(i+1))  # Mote ID
		moteIdBased_dutyCycle_file.write(' ')
		moteIdBased_dutyCycle_file.write(str(sumDutyCycle[i][0]))  # Number of logs for each mote
		moteIdBased_dutyCycle_file.write(' ')
		moteIdBased_dutyCycle_file.write(str(sumDutyCycle[i][1]))  # sum of all logged duty cycles to calculate average * 100 to get percent
		moteIdBased_dutyCycle_file.write(' ')
		moteIdBased_dutyCycle_file.write(str((float)(sumDutyCycle[i][1]*100)/sumDutyCycle[i][0]))  # average duty cycle
		moteIdBased_dutyCycle_file.write('\n')
	moteIdBased_dutyCycle_file.close()
dutyCycle_filehandler.close()

# Get Delay and PDR
Log_Snt_Rcv_file = open('_Get_snd_rcv_time.txt')
Log_Snt_Rcv_pkts = Log_Snt_Rcv_file.readlines()
Log_Snt_Rcv_file.close()

Log_Rcv_file = open('_Get_rcv_time.txt')
Log_Rcv_pkts = Log_Rcv_file.readlines()
Log_Rcv_file.close()

Delay_PDR_file = open('_Get_DELAY_PDR.txt', 'w')
List_Delay_file = open('_Get_List_DELAY.txt', 'w')
# _Get_List_DELAY.txt file shows moteID and each pkts delay
for i in xrange(Num_Mote):
	if i != 0:
		
		'''
		# Get number of openqueue sent pkts by a mote
		Snt_counter = 0
		for line in Log_Sndr_pkts:
			y = line.split()
			if int(y[0]) == i+1 and len(y) > 5 :
				Snt_counter += 1
		'''
		# Get number of uinject sent pkts by a mote
		UinjectSnt_counter = 0
		for line in Log_uinjectSndr_pkts:
			y = line.split()
			if int(y[0]) == i+1 and len(y) > 5 :
				UinjectSnt_counter += 1

		# Get number of received pkts from a mote to Sink
		Rcv_counter = 0
		for line in Log_Rcv_pkts:
			y = line.split()
			if int(y[0]) == i+1 and len(y) > 5 :
				Rcv_counter += 1

		min_Delay = 100000
		max_Delay = 0
		total_Time = 0
		for line in Log_Snt_Rcv_pkts:
			y = [value for value in line.split()]
			if int(y[0]) == i+1:
				if (int(y[1]) == int(y[5])) and (int(y[2]) == int(y[6])) and (int(y[3]) == int(y[7])):
					curr_Delay = int(y[4]) - int(y[8])
					total_Time += curr_Delay
					if curr_Delay > max_Delay :
						max_Delay = curr_Delay
					elif curr_Delay < min_Delay:
						min_Delay = curr_Delay
					List_Delay_file.write(str(i+1))
					List_Delay_file.write(' ')
					List_Delay_file.write(str(curr_Delay))
					List_Delay_file.write(' ')
					List_Delay_file.write(y[9])
					List_Delay_file.write('\n')
				elif (int(y[1]) == int(y[5])) and (int(y[2]) == int(y[6])):
					if (int(y[4]) > int(y[8])):
						curr_Delay = (int(y[3]) - int(y[7]))*1000 + (int(y[4]) - int(y[8]))
						total_Time += curr_Delay
						if curr_Delay > max_Delay :
							max_Delay = curr_Delay
						elif curr_Delay < min_Delay:
							min_Delay = curr_Delay
						List_Delay_file.write(str(i+1))
						List_Delay_file.write(' ')
						List_Delay_file.write(str(curr_Delay))
						List_Delay_file.write(' ')
						List_Delay_file.write(y[9])
						List_Delay_file.write('\n')
					else:
						curr_Delay = (int(y[3]) - int(y[7]))*1000 - (int(y[8]) - int(y[4]))
						total_Time += curr_Delay
						if curr_Delay > max_Delay :
							max_Delay = curr_Delay
						elif curr_Delay < min_Delay:
							min_Delay = curr_Delay
						List_Delay_file.write(str(i+1))
						List_Delay_file.write(' ')
						List_Delay_file.write(str(curr_Delay))
						List_Delay_file.write(' ')
						List_Delay_file.write(y[9])
						List_Delay_file.write('\n')

				elif (int(y[1]) == int(y[5])):
					if (int(y[3]) > int(y[7])):
						if (int(y[4]) > int(y[8])):
							curr_Delay = (int(y[2]) - int(y[6]))*60*1000 + (int(y[3]) - int(y[7]))*1000 + (int(y[4]) - int(y[8]))
							total_Time += curr_Delay
							if curr_Delay > max_Delay :
								max_Delay = curr_Delay
							elif curr_Delay < min_Delay:
								min_Delay = curr_Delay
							List_Delay_file.write(str(i+1))
							List_Delay_file.write(' ')
							List_Delay_file.write(str(curr_Delay))
							List_Delay_file.write(' ')
							List_Delay_file.write(y[9])
							List_Delay_file.write('\n')

						else:
							curr_Delay = (int(y[2]) - int(y[6]))*60*1000 + (int(y[3]) - int(y[7]))*1000 - (int(y[8]) - int(y[4]))
							total_Time += curr_Delay
							if curr_Delay > max_Delay :
								max_Delay = curr_Delay
							elif curr_Delay < min_Delay:
								min_Delay = curr_Delay
							List_Delay_file.write(str(i+1))
							List_Delay_file.write(' ')
							List_Delay_file.write(' ')
							List_Delay_file.write(y[9])
							List_Delay_file.write(str(curr_Delay))
							List_Delay_file.write('\n')
					else:
						if (int(y[4]) > int(y[8])):
							curr_Delay = (int(y[2]) - int(y[6]))*60*1000 - (int(y[7]) - int(y[3]))*1000 + (int(y[4]) - int(y[8]))
							total_Time += curr_Delay
							if curr_Delay > max_Delay :
								max_Delay = curr_Delay
							elif curr_Delay < min_Delay:
								min_Delay = curr_Delay
							List_Delay_file.write(str(i+1))
							List_Delay_file.write(' ')
							List_Delay_file.write(str(curr_Delay))
							List_Delay_file.write(' ')
							List_Delay_file.write(y[9])
							List_Delay_file.write('\n')
						else:
							curr_Delay = (int(y[2]) - int(y[6]))*60*1000 - (int(y[7]) - int(y[3]))*1000 - (int(y[8]) - int(y[4]))
							total_Time += curr_Delay
							if curr_Delay > max_Delay :
								max_Delay = curr_Delay
							elif curr_Delay < min_Delay:
								min_Delay = curr_Delay
							List_Delay_file.write(str(i+1))
							List_Delay_file.write(' ')
							List_Delay_file.write(str(curr_Delay))
							List_Delay_file.write(' ')
							List_Delay_file.write(y[9])
							List_Delay_file.write('\n')
				else:
					if (int(y[2]) > int(y[6])):
						if (int(y[3]) > int(y[7])):
							if (int(y[4]) > int(y[8])):
								curr_Delay = (int(y[1]) - int(y[5]))*3600*1000 + (int(y[2]) - int(y[6]))*60*1000 + (int(y[3]) - int(y[7]))*1000 + (int(y[4]) - int(y[8]))
								total_Time += curr_Delay
								if curr_Delay > max_Delay :
									max_Delay = curr_Delay
								elif curr_Delay < min_Delay:
									min_Delay = curr_Delay
								List_Delay_file.write(str(i+1))
								List_Delay_file.write(' ')
								List_Delay_file.write(str(curr_Delay))
								List_Delay_file.write(' ')
								List_Delay_file.write(y[9])
								List_Delay_file.write('\n')
							else:
								curr_Delay = (int(y[1]) - int(y[5]))*3600*1000 + (int(y[2]) - int(y[6]))*60*1000 + (int(y[3]) - int(y[7]))*1000 - (int(y[8]) - int(y[4]))
								total_Time += curr_Delay
								if curr_Delay > max_Delay :
									max_Delay = curr_Delay
								elif curr_Delay < min_Delay:
									min_Delay = curr_Delay
								List_Delay_file.write(str(i+1))
								List_Delay_file.write(' ')
								List_Delay_file.write(str(curr_Delay))
								List_Delay_file.write(' ')
								List_Delay_file.write(y[9])
								List_Delay_file.write('\n')
						else:
							if (int(y[4]) > int(y[8])):
								curr_Delay = (int(y[1]) - int(y[5]))*3600*1000 + (int(y[2]) - int(y[6]))*60*1000 - (int(y[7]) - int(y[3]))*1000 + (int(y[4]) - int(y[8]))
								total_Time += curr_Delay
								if curr_Delay > max_Delay :
									max_Delay = curr_Delay
								elif curr_Delay < min_Delay:
									min_Delay = curr_Delay
								List_Delay_file.write(str(i+1))
								List_Delay_file.write(' ')
								List_Delay_file.write(str(curr_Delay))
								List_Delay_file.write(' ')
								List_Delay_file.write(y[9])
								List_Delay_file.write('\n')
							else:
								curr_Delay = (int(y[1]) - int(y[5]))*3600*1000 + (int(y[2]) - int(y[6]))*60*1000 - (int(y[7]) - int(y[3]))*1000 - (int(y[8]) - int(y[4]))
								total_Time += curr_Delay
								if curr_Delay > max_Delay :
									max_Delay = curr_Delay
								elif curr_Delay < min_Delay:
									min_Delay = curr_Delay
								List_Delay_file.write(str(i+1))
								List_Delay_file.write(' ')
								List_Delay_file.write(str(curr_Delay))
								List_Delay_file.write(' ')
								List_Delay_file.write(y[9])
								List_Delay_file.write('\n')
					else:
						if (int(y[3]) > int(y[7])):
							if (int(y[4]) > int(y[8])):
								curr_Delay = (int(y[1]) - int(y[5]))*3600*1000 + (int(y[6]) - int(y[2]))*60*1000 + (int(y[3]) - int(y[7]))*1000 + (int(y[4]) - int(y[8]))
								total_Time += curr_Delay
								if curr_Delay > max_Delay :
									max_Delay = curr_Delay
								elif curr_Delay < min_Delay:
									min_Delay = curr_Delay
								List_Delay_file.write(str(i+1))
								List_Delay_file.write(' ')
								List_Delay_file.write(str(curr_Delay))
								List_Delay_file.write(' ')
								List_Delay_file.write(y[9])
								List_Delay_file.write('\n')
							else:
								curr_Delay = (int(y[1]) - int(y[5]))*3600*1000 + (int(y[6]) - int(y[2]))*60*1000 + (int(y[3]) - int(y[7]))*1000 - (int(y[8]) - int(y[4]))
								total_Time += curr_Delay
								if curr_Delay > max_Delay :
									max_Delay = curr_Delay
								elif curr_Delay < min_Delay:
									min_Delay = curr_Delay
								List_Delay_file.write(str(i+1))
								List_Delay_file.write(' ')
								List_Delay_file.write(str(curr_Delay))
								List_Delay_file.write(' ')
								List_Delay_file.write(y[9])
								List_Delay_file.write('\n')
						else:
							if (int(y[4]) > int(y[8])):
								curr_Delay = (int(y[1]) - int(y[5]))*3600*1000 + (int(y[6]) - int(y[2]))*60*1000 - (int(y[7]) - int(y[3]))*1000 + (int(y[4]) - int(y[8]))
								total_Time += curr_Delay
								if curr_Delay > max_Delay :
									max_Delay = curr_Delay
								elif curr_Delay < min_Delay:
									min_Delay = curr_Delay
								List_Delay_file.write(str(i+1))
								List_Delay_file.write(' ')
								List_Delay_file.write(str(curr_Delay))
								List_Delay_file.write(' ')
								List_Delay_file.write(y[9])
								List_Delay_file.write('\n')
							else:
								curr_Delay = (int(y[1]) - int(y[5]))*3600*1000 + (int(y[6]) - int(y[2]))*60*1000 - (int(y[7]) - int(y[3]))*1000 - (int(y[8]) - int(y[4]))
								total_Time += curr_Delay
								if curr_Delay > max_Delay :
									max_Delay = curr_Delay
								elif curr_Delay < min_Delay:
									min_Delay = curr_Delay
								List_Delay_file.write(str(i+1))
								List_Delay_file.write(' ')
								List_Delay_file.write(str(curr_Delay))
								List_Delay_file.write(' ')
								List_Delay_file.write(y[9])
								List_Delay_file.write('\n')
		  
		Delay_PDR_file.write(str(i+1))
		Delay_PDR_file.write(' ')

		Delay_PDR_file.write(str(UinjectSnt_counter))
		Delay_PDR_file.write(' ')
		Delay_PDR_file.write(str(Rcv_counter))
		
		PDR = 0
		if UinjectSnt_counter != 0:
			PDR = float(Rcv_counter)/UinjectSnt_counter  # Get PDR
		Delay_PDR_file.write(' ')
		Delay_PDR_file.write(str(PDR))  # Write PDR
		Delay_PDR_file.write(' ')
		Delay_PDR_file.write(str(total_Time))

		meanTime = 0
		if Rcv_counter != 0:
			meanTime = total_Time / Rcv_counter
		Delay_PDR_file.write(' ')
		Delay_PDR_file.write(str(meanTime))
		Delay_PDR_file.write(' ')
		Delay_PDR_file.write(str(min_Delay))
		Delay_PDR_file.write(' ')
		Delay_PDR_file.write(str(max_Delay))
		Delay_PDR_file.write('\n')
		

Delay_PDR_file.close()
List_Delay_file.close()
print(Num_Mote)
# Get average Queue Length
queueLogCounting = [-1 for j in range(Num_Mote)]
avgQueueLength = [[0 for i in range(2)] for j in range(Num_Mote)]

with open('_Log_QSize.txt') as queueLength_filehandler:
    queueLogCounting[0] = 1
    for line in queueLength_filehandler:
        y = line.split()
	if len(y) < 8: 
		#check_full_synch = 1
		#for i in range(Num_Mote):
		 #   if queueLogCounting[i] == -1:
		  #      queueLogCounting[int(y[0]) - 1] = 0
		   #     check_full_synch = 0
		#if  check_full_synch == 1:
	    avgQueueLength[int(y[0]) - 2][0] += 1
	    avgQueueLength[int(y[0]) - 2][1] += int(y[5])

    moteIdBased_queueLength_file = open('_Get_moteID_queueLength.txt', 'w')
    for i in range(Num_Mote-1):
        moteIdBased_queueLength_file.write(str(i + 1))  # Mote ID
        moteIdBased_queueLength_file.write(' ')
        moteIdBased_queueLength_file.write(str(avgQueueLength[i][0]))  # Number of logs for each mote
        moteIdBased_queueLength_file.write(' ')
        moteIdBased_queueLength_file.write(str(avgQueueLength[i][1]))  # sum of all logged queue length to calculate average
        moteIdBased_queueLength_file.write(' ')
        moteIdBased_queueLength_file.write(str((float)(avgQueueLength[i][1])/avgQueueLength[i][0]))  # average queue length
        moteIdBased_queueLength_file.write('\n')
    moteIdBased_queueLength_file.close()
queueLength_filehandler.close()

# Get CDF
# in gaining CDF we have to set some parameters manually, periods must be set
List_Delayfile = open('_Get_List_DELAY.txt')
List_Delay = List_Delayfile.readlines()
List_Delayfile.close()

CDF_array = []
CDF_total = []
for i in range(101):
	CDF_array.append([])
	CDF_array[i].append(i*10)
	CDF_array.append([])
	CDF_array[i].append(0)
CDF_array_size = len(CDF_array)/len(CDF_array[0])

for i in xrange(Num_Mote):
	if i != 0:
		counter = 0
		for line in List_Delay:
			y = [value for value in line.split()]
			Mote_ID = int(y[0])
			if Mote_ID == i+1:
				counter += 1
				pkt_delay = int(y[1])
				div = pkt_delay / 10
				if (pkt_delay%10) != 0:
					div += 1
				
				if div <= (CDF_array_size - 1):
					limit = div
				else:
					limit = CDF_array_size - 1

				t = limit
				while t <= (CDF_array_size - 1):
					tmp = int(CDF_array[t][0])
					if tmp >= pkt_delay:
						cnt = int(CDF_array[t][1])
						cnt += 1
						CDF_array[t][1] = cnt
					t += 1

		for c in xrange(CDF_array_size):
			CDF_total.append([])
			CDF_total[c].append(float(CDF_array[c][1])/counter)
			CDF_array[c][1] = 0

CDF_file = open('_Get_CDF.txt','w')
				# number of raws in array
for j in xrange(CDF_array_size): # here it means that every 50 ms period 
	CDF_file.write(str(j))
	CDF_file.write(' ')
	for i in xrange(Num_Mote-1):
		CDF_file.write(str(CDF_total[j][i]))
		CDF_file.write(' ')
	CDF_file.write('\n')
				  
CDF_file.close()

# Get hop count comparison

hopCount = []
max_hopCount = 2

hopCount.append([])
hopCount[0].append(2)
hopCount.append([])
hopCount[0].append(4)
hopCount.append([])
hopCount[1].append(3)

# get average CDF based on level of hop counts
avg_cdf = []
for i in range(101):
    avg_cdf.append([])
    avg_cdf[i].append(i*10)


Avg_CDF_file = open('_hopBased_CDF_Avg.txt','w')
for q in range(3):
    avg_cdf.append([])
    avg_cdf[0].append(0)

for j in xrange(1,CDF_array_size): # here it means that every 50 ms period 
    for z in xrange(max_hopCount):
        sum = 0
        for i in xrange(len(hopCount[z])):
            sum += float(CDF_total[j][hopCount[z][i]-2])
        avg = float(sum) / len(hopCount[z])
        avg_cdf.append([])
        avg_cdf[j].append(str(avg))
 
                # number of raws in array
for j in xrange(CDF_array_size): # here it means that every 50 ms period 
    Avg_CDF_file.write(str(j))
    Avg_CDF_file.write(' ')
    for i in range(1,max_hopCount+1):
        Avg_CDF_file.write(str(avg_cdf[j][i]))
        Avg_CDF_file.write(' ')
    Avg_CDF_file.write('\n') 
        
Avg_CDF_file.close()

# Get hop count comparison
hopCount_file = open('_Get_hopCount.txt','w')

for i in xrange(max_hopCount):
    hopCount_file.write(str(i+1))
    hopCount_file.write(' ')
    for j in xrange(len(hopCount[i])):
        Delay_PDR_file = open('_Get_DELAY_PDR.txt')
        for line in Delay_PDR_file:
            y = line.split()
            if (int(y[0]) == hopCount[i][j]):
                hopCount_file.write(y[5])
                hopCount_file.write(' ')
        Delay_PDR_file.close()
    hopCount_file.write('\n')
    hopCount_file.write('\n')
              
hopCount_file.close()



# Get  Confidence Interval and rewrite Delay and PDR
List_Delay_file = open('_Get_List_DELAY.txt')
Log_lst_delay = List_Delay_file.readlines()
List_Delay_file.close()

Delay_PDR_file = open('_Get_DELAY_PDR.txt')
tmp_delay_pdr = Delay_PDR_file.readlines()
Delay_PDR_file.close()

Delay_PDR_file = open('_Get_DELAY_PDR.txt', 'w')

meanTime_array = []
for t in xrange(Num_Mote):
	if t != 0:
		for each_line in tmp_delay_pdr:
			x = [value for value in each_line.split()]
			if int(x[0]) == t+1:
				meanTime_array.append(x[5])

confidence_array = []
compute_Deviation = 0
for t in xrange(Num_Mote):
	if t != 0:
		compute_Deviation = 0
		for each_line in Log_lst_delay:
			y = [value for value in each_line.split()]
			if int(y[0]) == t+1:
				compute_Deviation += pow((int(y[1])-(int(meanTime_array[t-1]))),2)

	sigma = math.sqrt(float(compute_Deviation)/(Rcv_counter-1))
	Confid_bound = (1.96*(float(sigma)/math.sqrt(Rcv_counter)))
	confidence_array.append(Confid_bound)

for t in xrange(Num_Mote):
	if t != 0:
		for each_line in tmp_delay_pdr:
			y = [value for value in each_line.split()]
			if int(y[0]) == t+1:
				y.append(confidence_array[t])
				Delay_PDR_file.write(str(int(y[0])))
				Delay_PDR_file.write(' ')
				Delay_PDR_file.write(str(int(y[1])))
				Delay_PDR_file.write(' ')
				Delay_PDR_file.write(str(int(y[2])))
				Delay_PDR_file.write(' ')
				Delay_PDR_file.write(str(float(y[3])))
				Delay_PDR_file.write(' ')
				Delay_PDR_file.write(str(int(y[4])))
				Delay_PDR_file.write(' ')
				Delay_PDR_file.write(str(int(y[5])))
				Delay_PDR_file.write(' ')
				Delay_PDR_file.write(str(int(y[6])))
				Delay_PDR_file.write(' ')
				Delay_PDR_file.write(str(int(y[7])))
				Delay_PDR_file.write(' ')
				Delay_PDR_file.write(str(float(y[8])))
				Delay_PDR_file.write('\n')

Delay_PDR_file.close()
