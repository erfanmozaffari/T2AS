#!/bin/bash

cd ./plotsANDscripts

getQueueFile="_Get_moteID_queueLength.txt"
getDelayAndPdrFile="_Get_DELAY_PDR.txt"
getADCFile="_Get_moteID_dutyCycle.txt"
getCDFFile="_Get_CDF.txt"

resultPath="../topoBasedResults/"

HS="HS"
T2AS="T2AS"
for i in 4 6 8 10 12 14 16
do
	color="blue"
	pathHS="../hs/"$i"Motes/results/"
	gnuplot -c ADC_eachTopo.plot $getADCFile $pathHS $i $resultPath $HS $color
	gnuplot -c CDF_eachTopo.plot $getCDFFile $pathHS $i $resultPath $HS $color
	gnuplot -c PDR_eachTopo.plot $getDelayAndPdrFile $pathHS $i $resultPath $HS $color
	gnuplot -c Delay_eachTopo.plot $getDelayAndPdrFile $pathHS $i $resultPath $HS $color
	gnuplot -c QueueLength_eachTopo.plot $getQueueFile $pathHS $i $resultPath $HS $color
	
	color="red"
	pathT2AS="../t2as/"$i"Motes/results/"
	gnuplot -c ADC_eachTopo.plot $getADCFile $pathT2AS $i $resultPath $T2AS $color
	gnuplot -c CDF_eachTopo.plot $getCDFFile $pathT2AS $i $resultPath $T2AS $color
	gnuplot -c PDR_eachTopo.plot $getDelayAndPdrFile $pathT2AS $i $resultPath $T2AS $color
	gnuplot -c Delay_eachTopo.plot $getDelayAndPdrFile $pathT2AS $i $resultPath $T2AS $color
	gnuplot -c QueueLength_eachTopo.plot $getQueueFile $pathT2AS $i $resultPath $T2AS $color
done