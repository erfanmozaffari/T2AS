#!/bin/bash

cd ./plotsANDscripts

getQueueFile="_Get_moteID_queueLength.txt"
getDelayAndPdrFile="_Get_DELAY_PDR.txt"
getADCFile="_Get_moteID_dutyCycle.txt"
getCDFFile="_Get_CDF.txt"

resultPath="../topoBasedResults/"

HS="HS"
T2AS="T2AS"
for i in 4 6 8 10 12 14 16
do
	color="blue"
	pathHS="../hs/"$i"Motes/results/"
	gnuplot -c ADC_eachTopo.plot $getADCFile $pathHS $i $resultPath $HS $color
	gnuplot -c CDF_eachTopo.plot $getCDFFile $pathHS $i $resultPath $HS $color
	gnuplot -c PDR_eachTopo.plot $getDelayAndPdrFile $pathHS $i $resultPath $HS $color
	gnuplot -c Delay_eachTopo.plot $getDelayAndPdrFile $pathHS $i $resultPath $HS $color
	gnuplot -c QueueLength_eachTopo.plot $getQueueFile $pathHS $i $resultPath $HS $color
	
	color="red"
	pathT2AS="../t2as/"$i"Motes/results/"
	gnuplot -c ADC_eachTopo.plot $getADCFile $pathT2AS $i $resultPath $T2AS $color
	gnuplot -c CDF_eachTopo.plot $getCDFFile $pathT2AS $i $resultPath $T2AS $color
	gnuplot -c PDR_eachTopo.plot $getDelayAndPdrFile $pathT2AS $i $resultPath $T2AS $color
	gnuplot -c Delay_eachTopo.plot $getDelayAndPdrFile $pathT2AS $i $resultPath $T2AS $color
	gnuplot -c QueueLength_eachTopo.plot $getQueueFile $pathT2AS $i $resultPath $T2AS $color
done


./getAverageAll.py

resultPath="../comparison/"

for i in 4 6 8 10 12 14 16
do
	# PDR & DELAY
	pathHS="../hs/"$i"Motes/results/_Get_DELAY_PDR.txt"
	pathT2AS="../t2as/"$i"Motes/results/_Get_DELAY_PDR.txt"
	gnuplot -c Delay_moteNumBased.plot $pathT2AS $pathHS $i $resultPath
	gnuplot -c PDR_moteNumBased.plot $pathT2AS $pathHS $i $resultPath
	
	# QUEUE LENGTH
	pathHS="../hs/"$i"Motes/results/_Get_moteID_queueLength.txt"
	pathT2AS="../t2as/"$i"Motes/results/_Get_moteID_queueLength.txt"
	gnuplot -c QueueLength_moteNumBased.plot $pathT2AS $pathHS $i $resultPath
	
	# DUTY CYCLE
	pathHS="../hs/"$i"Motes/results/_Get_moteID_dutyCycle.txt"
	pathT2AS="../t2as/"$i"Motes/results/_Get_moteID_dutyCycle.txt"
	gnuplot -c ADC_moteNumBased.plot $pathT2AS $pathHS $i $resultPath
	
	# CDF
	pathHS="../hs/"$i"Motes/results/_hopBased_CDF_Avg.txt"
	pathT2AS="../t2as/"$i"Motes/results/_hopBased_CDF_Avg.txt"
	gnuplot -c CDF_moteNumBased.plot $pathT2AS $pathHS $i $resultPath
	
done
inputPath="avgAll.txt"
gnuplot -c ADC_All.plot $inputPath $resultPath
gnuplot -c Delay_All.plot $inputPath $resultPath
gnuplot -c PDR_All.plot $inputPath $resultPath
gnuplot -c QueueLength_All.plot $inputPath $resultPath

inputPath="energyForOneSlotFrame.txt"
gnuplot -c energyConsumption_All.plot $inputPath $resultPath


cd ./../queue/fluctuation

UinjectAppFile="_Get_UINJECTsndr_time.txt"
resultPath="../topoBasedResults/"


resultPath="../../comparison/"
pathT2AS="avg_difference"$whichMote$T2AS".txt"
pathHS="avg_difference"$whichMote$HS".txt"

gnuplot -c queueFluct.plot $pathT2AS $pathHS $resultPath "HS" "T2AS"


cd ./../diffQueueSize
resultPath="../../comparison/"
inputFileName="allQueuingDelay-v2.txt"
gnuplot -c avgDiffQsize.plot $inputFileName $resultPath "HS" "T2AS"

