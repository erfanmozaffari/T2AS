#!/usr/bin/env python

import sys
import math

finalPath = ""
finalPath += sys.argv[1]
finalPath +="avgQueuingDelayHS"
finalPath += sys.argv[3]
finalPath += ".txt"
infile = open(finalPath, 'r')
hsHandler = infile.readlines()
for line in hsHandler:
	y = line.split()
infile.close()

finalPath = ""
finalPath += sys.argv[2]
finalPath +="avgQueuingDelayT2AS"
finalPath += sys.argv[3]
finalPath += ".txt"
infile = open(finalPath, 'r')
t2asHandler = infile.readlines()
for line in t2asHandler:
	x = line.split()
infile.close()

finalPath = ""
finalPath += "allQueuingDelay.txt"
outfile = open(finalPath, 'a')
outfile.write(sys.argv[3])
outfile.write(' ')
outfile.write(str(x[5]))
outfile.write(' ')
outfile.write(str(y[5]))
outfile.write('\n')

outfile.close()
