#!/bin/bash

resultPath="../../comparison/"
inputFileName="allQueuingDelay.txt"
gnuplot -c avgDiffQsize.plot $inputFileName $resultPath "HS" "T2AS"
