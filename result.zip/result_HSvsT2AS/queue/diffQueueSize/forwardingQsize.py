#!/usr/bin/env python

import sys
import math

# Get open queue sent time of a packet
finalPath = ""
finalPath += sys.argv[3]
finalPath += sys.argv[2]
with open(finalPath) as Snt_file:
	finalPath = ""
	finalPath += sys.argv[3]
	finalPath += "filterDataDequeue"
	finalPath += sys.argv[4]
	finalPath += sys.argv[5]
	finalPath += sys.argv[6]
	finalPath += ".txt"
	snd_timefile = open(finalPath,'w')
	for line in Snt_file:
		y = line.split()
		if len(y) == 7  or len(y)==8: # First Line of a logged Packet
			snd_timefile.write(y[0])  # relay mote
			snd_timefile.write(' ')
			snd_timefile.write(y[1])  # Snt hour
			snd_timefile.write(' ')
			snd_timefile.write(y[2])  # Snt minutes
			snd_timefile.write(' ')
			snd_timefile.write(y[3])  # Snt sec
			snd_timefile.write(' ')
			snd_timefile.write(y[4])  # Snt ms
			snd_timefile.write(' ')
			snd_timefile.write(y[5])  # Sender's ID
			snd_timefile.write(' ')
			SenderID = y[5]
		elif len(y) > 8:  # Second Line of a logged Packet
			for index in range(len(y)):
				if (int(y[index]) == 20) and (int(y[index+1]) == 200) and (int(y[index-3]) == int(SenderID)):
					pktID=int(y[index-2])*255+int(y[index-1])
					snd_timefile.write(str(pktID))  # Packet ID
					break
			snd_timefile.write('\n')
	snd_timefile.close()
Snt_file.close()

# Get uinject sent time of a packet
finalPath = ""
finalPath += sys.argv[3]
finalPath += sys.argv[1]
with open(finalPath) as uinjectSnt_file:
	finalPath = ""
	finalPath += sys.argv[3]
	finalPath += "filterDataEnqueue"
	finalPath += sys.argv[4]
	finalPath += sys.argv[5]
	finalPath += sys.argv[6]
	finalPath += ".txt"
	uinjectsnd_timefile = open(finalPath,'w')
	for line in uinjectSnt_file:
		y = line.split()
		if len(y) == 7  or len(y)==8: # First Line of a logged Packet
			uinjectsnd_timefile.write(y[0])  # Mote ID
			uinjectsnd_timefile.write(' ')
			uinjectsnd_timefile.write(y[1])  # Snt hour
			uinjectsnd_timefile.write(' ')
			uinjectsnd_timefile.write(y[2])  # Snt minutes
			uinjectsnd_timefile.write(' ')
			uinjectsnd_timefile.write(y[3])  # Snt sec
			uinjectsnd_timefile.write(' ')
			uinjectsnd_timefile.write(y[4])  # Snt ms
			uinjectsnd_timefile.write(' ')
			uinjectsnd_timefile.write(y[5])  # Sender's ID
			uinjectsnd_timefile.write(' ')
			SenderID = y[5]
		elif len(y) > 8:  # Second Line of a logged Packet
			for index in range(len(y)):
				if (int(y[index]) == 20) and (int(y[index+1]) == 200) and (int(y[index-3]) == int(SenderID)):
					pktID=int(y[index-2])*255+int(y[index-1])
					uinjectsnd_timefile.write(str(pktID))  # Packet ID
					break
			uinjectsnd_timefile.write('\n')
	uinjectsnd_timefile.close()
uinjectSnt_file.close()


# measure delay
finalPath = ""
finalPath += sys.argv[3]
finalPath += "filterDataDequeue"
finalPath += sys.argv[4]
finalPath += sys.argv[5]
finalPath += sys.argv[6]
finalPath += ".txt"
infile = open(finalPath, 'r')
DequeueHandler = infile.readlines()
infile.close()

finalPath = ""
finalPath += sys.argv[3]
finalPath += "filterDataEnqueue"
finalPath += sys.argv[4]
finalPath += sys.argv[5]
finalPath += sys.argv[6]
finalPath += ".txt"
infile = open(finalPath, 'r')
EnqueueHandler = infile.readlines()
infile.close()

finalPath = ""
finalPath += sys.argv[3]
finalPath += "queueingDelay"
finalPath += sys.argv[4]
finalPath += sys.argv[5]
finalPath += sys.argv[6]
finalPath += ".txt"
outfile = open(finalPath, 'w')

for line in DequeueHandler:
	y = line.split()
	if int(y[0]) == int(sys.argv[7]):
		dequeueTime = int(y[1])*3600000 + int(y[2])*60000 + int(y[3])*1000 + int(y[4])
		for enq in EnqueueHandler:
			x = enq.split()
			if (int(y[0])==int(x[0])) and (int(y[5])==int(x[5])) and (int(y[6])==int(x[6])):
				enqueueTime = int(x[1])*3600000 + int(x[2])*60000 + int(x[3])*1000 + int(x[4])
				diffTime = dequeueTime - enqueueTime
				outfile.write(y[0])  # Current mote
				outfile.write(' ')
				outfile.write(y[5])  # src addr
				outfile.write(' ')
				outfile.write(y[6])  # pktID
				outfile.write(' ')
				outfile.write(str(diffTime))  # queueing delay in Milisecond
				outfile.write('\n')

outfile.close()
