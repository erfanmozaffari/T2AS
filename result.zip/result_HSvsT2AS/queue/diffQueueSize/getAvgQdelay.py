#!/usr/bin/env python

import sys
import math

finalPath = ""
finalPath += sys.argv[3]
finalPath += sys.argv[2]
infile = open(finalPath, 'r')
dataHandler = infile.readlines()
infile.close()

datapktCounter = 0
dataTotalDelay = 0
for line in dataHandler:
	y = line.split()
	datapktCounter+=1
	dataTotalDelay += int(y[3])

finalPath = ""
finalPath += sys.argv[3]
finalPath += sys.argv[1]
infile = open(finalPath, 'r')
fwHandler = infile.readlines()
infile.close()

fwpktCounter = 0
fwTotalDelay = 0
for line in fwHandler:
	y = line.split()
	fwpktCounter+=1
	fwTotalDelay+= int(y[3])
		
meanDelay = (float)(fwTotalDelay+dataTotalDelay)/(fwpktCounter+datapktCounter)
		
finalPath = ""
finalPath += sys.argv[3]
finalPath += "avgQueuingDelay"
finalPath += sys.argv[5]
finalPath += sys.argv[4]
finalPath += ".txt"
outfile = open(finalPath, 'w')
outfile.write(str(fwpktCounter))
outfile.write(' ')
outfile.write(str(fwTotalDelay))
outfile.write(' ')
outfile.write(str(datapktCounter))
outfile.write(' ')
outfile.write(str(dataTotalDelay))
outfile.write(' ')
outfile.write(str(datapktCounter+fwpktCounter)) # count total number of packets
outfile.write(' ')
outfile.write(str(meanDelay))
outfile.write('\n')

outfile.close()
