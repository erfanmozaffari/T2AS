#!/bin/bash

HS="HS"
T2AS="T2AS"
whichMote=13

# list of queue sizes
for i in 10 20 30
do
	EnqueueFile="_Log_UINJECTApp_Sndr.txt"
	DequeueFile="_Log_OpenQueue_Snt.txt"
	pktType="Data"
	logPath="hs16/q="$i"/"
	./UinjectQsize.py $EnqueueFile $DequeueFile $logPath $i $HS $pktType $whichMote
	logPath="t2as16/q="$i"/" 
	./UinjectQsize.py $EnqueueFile $DequeueFile $logPath $i $T2AS $pktType $whichMote
	
	
	EnqueueFile="_Log_forwardinglevel.txt"
	DequeueFile="_Log_forwardingQueue.txt"
	pktType="FW"
	logPath="hs16/q="$i"/"
	./forwardingQsize.py $EnqueueFile $DequeueFile $logPath $i $HS $pktType $whichMote
	logPath="t2as16/q="$i"/"
	./forwardingQsize.py $EnqueueFile $DequeueFile $logPath $i $T2AS $pktType $whichMote
	
done

for i in 10 20 30
do
	fwFile="queueingDelay"$i$HS"FW.txt"
	dataFile="queueingDelay"$i$HS"Data.txt"
	logPath="hs16/q="$i"/"
	./getAvgQdelay.py $fwFile $dataFile $logPath $i $HS
	
	fwFile="queueingDelay"$i$T2AS"FW.txt"
	dataFile="queueingDelay"$i$T2AS"Data.txt"
	logPath="t2as16/q="$i"/"
	./getAvgQdelay.py $fwFile $dataFile $logPath $i $T2AS
done

rm allQueuingDelay.txt # because it is opened for appending 
for i in 10 20 30
do
	hsPath="hs16/q="$i"/"
	t2asPath="t2as16/q="$i"/"
	./allAvgInOneFile.py $hsPath $t2asPath $i
done

./queuePlot.sh
